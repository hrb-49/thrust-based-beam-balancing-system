#include "I2C.h"

// ============================================================================
//                           I2C1 IMPLEMENTATION
// ============================================================================
// This module provides low-level I2C1 functions for the TM4C123 microcontroller,
// including initialization, register writing, and multi-byte reading.
// ============================================================================

/**
 * @brief Initializes the I2C1 peripheral.
 * 
 * Enables clocks for I2C1 and GPIOA, configures pins PA6 (SCL) and PA7 (SDA)
 * for alternate function I2C operation, and sets I2C1 master mode with 
 * a target frequency of ~100kHz assuming a 16 MHz system clock.
 */
void I2C1_Init(void) {
    SYSCTL->RCGCI2C |= (1 << 1);      // Enable clock for I2C1 module
    SYSCTL->RCGCGPIO |= (1 << 0);     // Enable clock for Port A
    (void)SYSCTL->RCGCGPIO;           // Dummy read to allow clock stabilization

    GPIOA->AFSEL |= (1 << 6) | (1 << 7); // Enable alternate functions on PA6, PA7
    GPIOA->ODR   |= (1 << 7);            // Enable open-drain on SDA (PA7)
    GPIOA->DEN   |= (1 << 6) | (1 << 7); // Enable digital function on PA6, PA7
    GPIOA->PCTL &= ~0xFF000000;          // Clear PCTL bits for PA6, PA7
    GPIOA->PCTL |= (3 << 24) | (3 << 28); // Set PA6, PA7 to I2C1 function

    I2C1->MCR = (1 << 4);               // Enable I2C1 master mode
    I2C1->MTPR = 7;                     // Configure SCL clock for ~100kHz at 16MHz system clock
}

/**
 * @brief Waits until the I2C1 master operation is complete.
 */
void I2C1_Wait(void) {
    while (I2C1->MCS & 1); // Wait while the BUSY bit is set
}

/**
 * @brief Writes a single byte to a specific register of an I2C slave device.
 * 
 * @param dev  7-bit I2C device address
 * @param reg  Register address within the slave device
 * @param val  Data byte to be written
 */
void I2C1_WriteReg(uint8_t dev, uint8_t reg, uint8_t val) {
    I2C1_Wait();
    I2C1->MSA = dev << 1;      // Set slave address with write bit
    I2C1->MDR = reg;           // Load register address
    I2C1->MCS = 3;             // Send START + RUN
    I2C1_Wait();

    I2C1->MDR = val;           // Load data to send
    I2C1->MCS = 5;             // Send STOP + RUN
    I2C1_Wait();
}

/**
 * @brief Reads multiple bytes from a slave device starting at a given register.
 * 
 * @param dev  7-bit I2C device address
 * @param reg  Starting register address
 * @param buf  Pointer to data buffer for received bytes
 * @param len  Number of bytes to read
 */
void I2C1_ReadMulti(uint8_t dev, uint8_t reg, uint8_t *buf, uint8_t len) {
    I2C1_Wait();
    I2C1->MSA = dev << 1;      // Set slave address for write
    I2C1->MDR = reg;           // Load register address
    I2C1->MCS = 3;             // Send START + RUN
    I2C1_Wait();

    I2C1->MSA = (dev << 1) | 1; // Switch to read mode

    // If reading one byte, send START + STOP
    if (len == 1)
        I2C1->MCS = 7;
    else
        I2C1->MCS = 0x0B;       // START + RUN + ACK

    for (uint8_t i = 0; i < len - 1; i++) {
        while (I2C1->MCS & 1);  // Wait for current byte
        buf[i] = I2C1->MDR;     // Read received data

        // Send next byte or prepare to stop
        if (i == len - 2)
            I2C1->MCS = 5;      // STOP + RUN
        else
            I2C1->MCS = 9;      // CONTINUE + RUN
    }

    while (I2C1->MCS & 1);      // Wait for last byte
    buf[len - 1] = I2C1->MDR;   // Store final byte
}
