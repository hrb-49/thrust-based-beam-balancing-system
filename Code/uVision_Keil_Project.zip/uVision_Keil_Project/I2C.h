#ifndef I2C_H
#define I2C_H

#include "TM4C123.h"
#include <stdint.h>

// I2C1 Driver Interface

void I2C1_Init(void);
void I2C1_Wait(void);
void I2C1_WriteReg(uint8_t dev, uint8_t reg, uint8_t val);
void I2C1_ReadMulti(uint8_t dev, uint8_t reg, uint8_t *buf, uint8_t len);

#endif // I2C_H
