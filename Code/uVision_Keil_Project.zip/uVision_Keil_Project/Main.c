#include "TM4C123.h"
#include "pwm.h"
#include "rpm.h"
#include "uart.h"
#include "current_sensor.h"
#include "mpu6050.h"
#include "I2C.h"
#include "pid.h"            // ===== NEW =====

#define SYSCLK 16000000UL

// ===== PID + BALANCE DEFINES =====
#define BASE_THROTTLE   1230.0f     // ESC idle throttle
#define ROLL_DEADBAND   0.3f       // ~�5% deadband (degrees)
#define PID_DT          0.02f       // 50 Hz loop

// ---------------- RPM VALUES ----------------
extern volatile unsigned int rpm1;
extern volatile unsigned int rpm2;

// ---------------- PWM PULSE WIDTHS ----------
extern volatile unsigned long pulse_us1;
extern volatile unsigned long pulse_us2;

// ---------------- MPU VARIABLES --------------
int16_t accel[3];
int16_t gyro[3];
extern float roll_angle_deg;

// ===== PID INSTANCE =====
PID_t rollPID;

int main(void)
{
    // ================= SYSTEM INIT =================
    PLL_Init();
    UART0_Init();


    // ================= ADC INIT ====================
    CurrentSensors_ADC1_Init();     // Current sensors

    // ================= PWM INIT ====================
    Timer0A_50Hz_Init();
    Timer1A_OneShot_Init();
    Timer2A_OneShot_Init();

    // ================= RPM SENSOR INIT ==============
    RPM_Sensor1_Input_Init_PB2();
    RPM_Sensor2_Input_Init_PB3();
    RPM_Timer3A_1s_Init();

    // ================= CURRENT SENSOR CAL ==========
    SysTick_DelayMs(100);
    CurrentSensors_Calibrate();

    __enable_irq();

    // ================= I2C + MPU INIT ===============
    I2C1_Init();
    SysTick_DelayMs(20);

    MPU6050_Init();
    SysTick_DelayMs(100);

    UART0_PrintString("Calibrating MPU6050...");
    MPU6050_Calibrate();
    UART0_PrintString(" Done\r\n");

    MPU6050_ReadRaw(accel, gyro);
    MPU6050_CalculateRoll(accel, gyro);
    roll_angle_deg = 0.0f;

    // ================= PID INIT =====================
    PID_Init(&rollPID, 0.5f, 0.008f, 0.12f);   // Safe starting gains

    // ================= MAIN LOOP ====================
    while (1)
    {
        // -------- 2. MPU READ + ROLL -----------------
        MPU6050_ReadRaw(accel, gyro);
        MPU6050_CalculateRoll(accel, gyro);

        float roll = roll_angle_deg;
        float pid_out = 0.0f;

        // -------- 3. DEAD BAND + PID -----------------
        if (roll > ROLL_DEADBAND || roll < -ROLL_DEADBAND)
        {
            pid_out = PID_Compute(&rollPID, 0.0f, roll, PID_DT);
        }
        else
        {
            // Ensure initial slow start if roll ~0
            pid_out = PID_Compute(&rollPID, 0.0f, roll, PID_DT);
        }

        // -------- 4. MOTOR MIXING (BALANCE) ----------
        pulse_us1 = BASE_THROTTLE + pid_out;   // Left motor
        pulse_us2 = BASE_THROTTLE - pid_out;   // Right motor

        // -------- 5. CLAMP ESC LIMITS ----------------
        if (pulse_us1 > 1240) pulse_us1 = 1240;
        if (pulse_us1 < 1000) pulse_us1 = 1000;

        if (pulse_us2 > 1212) pulse_us2 = 1212;
        if (pulse_us2 < 1000) pulse_us2 = 1000;

        // -------- 6. CURRENT SENSORS -----------------
        uint32_t c1_adc = ADC1_Read_PE1();
        uint32_t c2_adc = ADC1_Read_PE2();

        int32_t c1_mA = Current_PE1_mA(c1_adc);
        int32_t c2_mA = Current_PE2_mA(c2_adc);

        // ================= TELEMETRY =================
        UART0_PrintString("RPM1:");
        UART0_PrintNumber(rpm1);

        UART0_PrintString(" RPM2:");
        UART0_PrintNumber(rpm2);

        UART0_PrintString(" P1:");
        UART0_PrintNumber(pulse_us1);

        UART0_PrintString(" P2:");
        UART0_PrintNumber(pulse_us2);

        UART0_PrintString(" I1:");
        UART0_PrintCurrentA_from_mA(c1_mA);

        UART0_PrintString(" I2:");
        UART0_PrintCurrentA_from_mA(c2_mA);

        UART0_PrintString(" Roll:");
        UART0_PrintSignedNumber(roll);

        UART0_PrintString("\r\n");

        SysTick_DelayMs(20);   // 50 Hz control loop
    }
}
