#include "current_sensor.h"
#include "TM4C123.h"

#define SYSCLK 16000000UL

// ================= ACS712 30A =================
#define COUNTS_PER_AMP_BASE 82
#define MA_PER_AMP          1000

// ================= GLOBAL SCALE FIX =================
// Reduces 5�12A readings to realistic 0.4�2A
#define GLOBAL_CURRENT_SCALE 0.20f

// ================= CHANNEL GAIN CORRECTION =================
#define PE1_GAIN_CORR       0.90f
#define PE2_GAIN_CORR       1.00f

// ================= FILTERING ==================
#define ADC_AVG_SAMPLES     48
#define CALIB_SAMPLES       400
#define LPF_ALPHA           0.06f
#define ZERO_DEADBAND_MA    100
#define MAX_CURRENT_MA      10000   // 10A realistic upper bound

// =================================================
static int32_t zeroOffset_PE1 = 0;
static int32_t zeroOffset_PE2 = 0;

static float filtered_mA_PE1 = 0;
static float filtered_mA_PE2 = 0;

// =================================================
void CurrentSensors_ADC1_Init(void)
{
    SYSCTL->RCGCADC  |= (1U << 1);
    SYSCTL->RCGCGPIO |= (1U << 4);
    for (volatile int i = 0; i < 20; i++);

    GPIOE->DIR   &= ~((1U << 1) | (1U << 2));
    GPIOE->AFSEL |=  (1U << 1) | (1U << 2);
    GPIOE->DEN   &= ~((1U << 1) | (1U << 2));
    GPIOE->AMSEL |=  (1U << 1) | (1U << 2);

    ADC1->ACTSS &= ~(1U << 3);
    ADC1->EMUX  &= ~(0xF << 12);
    ADC1->SSCTL3 = (1U << 1) | (1U << 2);
    ADC1->ACTSS |=  (1U << 3);
}

// =================================================
static uint32_t ADC1_Read_Channel(uint8_t channel)
{
    ADC1->ACTSS &= ~(1U << 3);
    ADC1->SSMUX3 = channel & 0xF;
    ADC1->ACTSS |=  (1U << 3);

    ADC1->PSSI = (1U << 3);
    while ((ADC1->RIS & (1U << 3)) == 0);

    uint32_t v = ADC1->SSFIFO3 & 0xFFF;
    ADC1->ISC = (1U << 3);
    return v;
}

// =================================================
static uint32_t ADC1_Read_Averaged(uint8_t channel)
{
    uint32_t sum = 0;
    for (int i = 0; i < ADC_AVG_SAMPLES; i++)
        sum += ADC1_Read_Channel(channel);

    return sum / ADC_AVG_SAMPLES;
}

uint32_t ADC1_Read_PE1(void) { return ADC1_Read_Averaged(2); }
uint32_t ADC1_Read_PE2(void) { return ADC1_Read_Averaged(1); }

// =================================================
void CurrentSensors_Calibrate(void)
{
    uint64_t s1 = 0, s2 = 0;

    for (int i = 0; i < CALIB_SAMPLES; i++)
    {
        s1 += ADC1_Read_PE1();
        s2 += ADC1_Read_PE2();
    }

    zeroOffset_PE1 = s1 / CALIB_SAMPLES;
    zeroOffset_PE2 = s2 / CALIB_SAMPLES;
}

// =================================================
int32_t Current_PE1_mA(uint32_t adc)
{
    float raw =
        ((int32_t)adc - zeroOffset_PE1) *
        MA_PER_AMP / COUNTS_PER_AMP_BASE;

    raw *= PE1_GAIN_CORR;
    raw *= GLOBAL_CURRENT_SCALE;

    filtered_mA_PE1 += LPF_ALPHA * (raw - filtered_mA_PE1);
    int32_t out = (int32_t)filtered_mA_PE1;

    if (out > -ZERO_DEADBAND_MA && out < ZERO_DEADBAND_MA) out = 0;
    if (out >  MAX_CURRENT_MA) out =  MAX_CURRENT_MA;
    if (out < -MAX_CURRENT_MA) out = -MAX_CURRENT_MA;

    return out;
}

int32_t Current_PE2_mA(uint32_t adc)
{
    float raw =
        ((int32_t)adc - zeroOffset_PE2) *
        MA_PER_AMP / COUNTS_PER_AMP_BASE;

    raw *= PE2_GAIN_CORR;
    raw *= GLOBAL_CURRENT_SCALE;

    filtered_mA_PE2 += LPF_ALPHA * (raw - filtered_mA_PE2);
    int32_t out = (int32_t)filtered_mA_PE2;

    if (out > -ZERO_DEADBAND_MA && out < ZERO_DEADBAND_MA) out = 0;
    if (out >  MAX_CURRENT_MA) out =  MAX_CURRENT_MA;
    if (out < -MAX_CURRENT_MA) out = -MAX_CURRENT_MA;

    return out;
}