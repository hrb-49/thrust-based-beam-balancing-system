#ifndef CURRENT_SENSOR_H
#define CURRENT_SENSOR_H

#include "TM4C123.h"
#include <stdint.h>

/*========================================================
    ADC1 Initialization
    CS1 ? PE1 (AIN2)
    CS2 ? PE2 (AIN1)
========================================================*/
void CurrentSensors_ADC1_Init(void);

/*========================================================
    Zero-current calibration
    (Call once at startup with motors OFF)
========================================================*/
void CurrentSensors_Calibrate(void);

/*========================================================
    Raw ADC Reads
========================================================*/
uint32_t ADC1_Read_PE1(void);   // Current Sensor 1 (PE1 / AIN2)
uint32_t ADC1_Read_PE2(void);   // Current Sensor 2 (PE2 / AIN1)

/*========================================================
    ADC ? Current Conversion (mA)
========================================================*/
int32_t Current_PE1_mA(uint32_t adc);  // CS1
int32_t Current_PE2_mA(uint32_t adc);  // CS2

#endif /* CURRENT_SENSOR_H */
