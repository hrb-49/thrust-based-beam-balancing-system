/**
 ******************************************************************************
 * @file    mpu6050.c
 * @brief   MPU6050 Roll Angle Calculation using Complementary Filter
 * @details
 *  - I2C1_SCL -> PA6
 *  - I2C1_SDA -> PA7
 *  - MPU6050 Address: 0x68
 ******************************************************************************
 */

#include <math.h>
#include <stdint.h>
#include "mpu6050.h"

// =======================================================
// ===================== CONSTANTS =======================
// =======================================================

// MPU6050 scale factors (+/-2g, +/-250 dps)
#define ACCEL_SCALE   16384.0f
#define GYRO_SCALE    131.0f
#define RAD_TO_DEG    57.29578f

// Complementary filter parameters
#define DT            0.020f      // 20 ms loop time
#define ALPHA         0.98f

// =======================================================
// ================= GLOBAL VARIABLES ====================
// =======================================================

int16_t gyro_bias[3]  = {0, 0, 0};
int16_t accel_bias[3] = {0, 0, 0};

float roll_angle_deg = 0.0f;

// =======================================================
// ================== SYSTICK DELAY ======================
// =======================================================

void SysTick_DelayMs(uint32_t ms)
{
    SysTick->LOAD = (SYSCLK / 1000) - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;

    for(uint32_t i = 0; i < ms; i++)
        while((SysTick->CTRL & 0x10000) == 0);

    SysTick->CTRL = 0;
}

// =======================================================
// ================= MPU6050 FUNCTIONS ===================
// =======================================================

void MPU6050_Init(void)
{
    I2C1_WriteReg(MPU6050_ADDR, 0x19, 7);   // Sample rate
    I2C1_WriteReg(MPU6050_ADDR, 0x1A, 3);   // DLPF
    I2C1_WriteReg(MPU6050_ADDR, 0x1B, 0);   // Gyro �250 dps
    I2C1_WriteReg(MPU6050_ADDR, 0x1C, 0);   // Accel �2g
    I2C1_WriteReg(MPU6050_ADDR, 0x6B, 0);   // Wake up
    SysTick_DelayMs(100);
}

uint8_t MPU6050_WhoAmI(void)
{
    uint8_t id;
    I2C1_ReadMulti(MPU6050_ADDR, 0x75, &id, 1);
    return id;
}

void MPU6050_ReadRaw(int16_t *accel, int16_t *gyro)
{
    uint8_t buf[14];
    I2C1_ReadMulti(MPU6050_ADDR, 0x3B, buf, 14);

    accel[0] = (buf[0] << 8) | buf[1];
    accel[1] = (buf[2] << 8) | buf[3];
    accel[2] = (buf[4] << 8) | buf[5];

    gyro[0]  = (buf[8]  << 8) | buf[9];
    gyro[1]  = (buf[10] << 8) | buf[11];
    gyro[2]  = (buf[12] << 8) | buf[13];

    // Apply bias correction
    gyro[0] -= gyro_bias[0];
    gyro[1] -= gyro_bias[1];
    gyro[2] -= gyro_bias[2];

    accel[0] -= accel_bias[0];
    accel[1] -= accel_bias[1];
}

// =======================================================
// =================== CALIBRATION =======================
// =======================================================

void MPU6050_Calibrate(void)
{
    int32_t gx = 0, gy = 0, gz = 0;
    int32_t ax = 0, ay = 0;

    int16_t accel[3], gyro[3];
    const int samples = 1000;

    for(int i = 0; i < samples; i++)
    {
        MPU6050_ReadRaw(accel, gyro);

        gx += gyro[0];
        gy += gyro[1];
        gz += gyro[2];

        ax += accel[0];
        ay += accel[1];

        SysTick_DelayMs(2);
    }

    gyro_bias[0]  = gx / samples;
    gyro_bias[1]  = gy / samples;
    gyro_bias[2]  = gz / samples;

    accel_bias[0] = ax / samples;
    accel_bias[1] = ay / samples;
}

// =======================================================
// ============ ROLL ANGLE CALCULATION ===================
// =======================================================

void MPU6050_CalculateRoll(int16_t *accel, int16_t *gyro)
{
    // --- Accelerometer Roll (Ay, Az) ---
    float Ay = (float)accel[1] / ACCEL_SCALE;
    float Az = (float)accel[2] / ACCEL_SCALE;

    float accel_roll_rad = atan2f(Ay, Az);
    float accel_roll_deg = accel_roll_rad * RAD_TO_DEG;

    // --- Gyroscope Roll Rate (X-axis) ---
    float Gx = (float)gyro[0] / GYRO_SCALE;

    // --- Complementary Filter ---
    float gyro_estimate = roll_angle_deg + (Gx * DT);

    roll_angle_deg =
        (ALPHA * gyro_estimate) +
        ((1.0f - ALPHA) * accel_roll_deg);
}
