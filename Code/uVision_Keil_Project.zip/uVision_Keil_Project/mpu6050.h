#ifndef MPU6050_H
#define MPU6050_H

#include "TM4C123.h"
#include <stdint.h>

/*---------------------------------------------------------
 * Device Information
 * --------------------------------------------------------
 * @brief MPU6050 (6-axis IMU sensor: 3-axis accelerometer + 3-axis gyroscope)
 *
 * Communication Interface: I?C
 * Default I?C Slave Address: 0x68
 * Clock Source: 16 MHz system clock
 * --------------------------------------------------------*/
#define MPU6050_ADDR 0x68          // I?C address for MPU6050 sensor
#define SYSCLK       16000000UL    // MCU system clock frequency (16 MHz)

/*---------------------------------------------------------
 * Pin Mapping (for I?C Communication)
 * --------------------------------------------------------
 * SDA ? PB3  (I?C0SDA) ? Data line for MPU6050
 * SCL ? PB2  (I?C0SCL) ? Clock line for MPU6050
 *
 * Note:
 *  - Both lines must have external pull-up resistors (typically 4.7 kO).
 *  - The MPU6050 uses standard I?C protocol with 7-bit addressing.
 * --------------------------------------------------------*/


/*---------------------------------------------------------
 * Function: SysTick_DelayMs
 * --------------------------------------------------------
 * @brief Generates a precise millisecond delay using the SysTick timer.
 *
 * @param ms  Number of milliseconds to delay.
 *
 * @note Based on 16 MHz system clock. Used for MPU6050 power-up and timing gaps.
 * --------------------------------------------------------*/
void SysTick_DelayMs(uint32_t ms);


/*---------------------------------------------------------
 * Function: MPU6050_Init
 * --------------------------------------------------------
 * @brief Initializes the MPU6050 sensor for operation.
 *
 * - Configures I?C communication via **Port B (PB2=SCL, PB3=SDA)**.
 * - Wakes up the MPU6050 from sleep mode.
 * - Sets up measurement ranges for accelerometer and gyroscope.
 *
 * @note Must be called once before reading sensor data.
 * --------------------------------------------------------*/
void MPU6050_Init(void);


/*---------------------------------------------------------
 * Function: MPU6050_WhoAmI
 * --------------------------------------------------------
 * @brief Reads the **WHO_AM_I** register (0x75) from the MPU6050.
 *
 * @return 8-bit device ID (expected: 0x68).
 *
 * @note Useful for verifying I?C communication integrity.
 * --------------------------------------------------------*/
uint8_t MPU6050_WhoAmI(void);


/*---------------------------------------------------------
 * Function: MPU6050_ReadRaw
 * --------------------------------------------------------
 * @brief Reads raw accelerometer and gyroscope data from the MPU6050.
 *
 * @param accel  Pointer to a 3-element array for raw acceleration (X, Y, Z).
 * @param gyro   Pointer to a 3-element array for raw angular velocity (X, Y, Z).
 *
 * @note
 *  - Accelerometer range: ?2g (default)
 *  - Gyroscope range: ?250?/s (default)
 *  - Data is in 16-bit signed format.
 * --------------------------------------------------------*/
void MPU6050_ReadRaw(int16_t *accel, int16_t *gyro);
void MPU6050_Calibrate(void);
void MPU6050_CalculateRoll(int16_t *accel, int16_t *gyro);
#endif /* MPU6050_H */
