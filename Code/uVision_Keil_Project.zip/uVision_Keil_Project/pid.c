#include "pid.h"

#define MAX_MOTOR_PULSE 1240      // Maximum safe motor pulse
#define INITIAL_PULSE   100       // Slow start pulse
#define INITIAL_DELAY   2.0f      // Seconds before MPU control starts

void PID_Init(PID_t *pid, float kp, float ki, float kd)
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
    pid->prevError = 0.0f;
    pid->integral = 0.0f;
    pid->elapsedTime = 0.0f;
}

float PID_Compute(PID_t *pid, float setpoint, float measured, float dt)
{
    pid->elapsedTime += dt;

    // Initial slow start
    if (pid->elapsedTime < INITIAL_DELAY)
    {
        return INITIAL_PULSE;
    }

    // PID calculation
    float error = setpoint - measured;
    pid->integral += error * dt;
    float derivative = (error - pid->prevError) / dt;
    pid->prevError = error;

    float output = (pid->Kp * error) +
                   (pid->Ki * pid->integral) +
                   (pid->Kd * derivative);

    // Saturate output
    if (output > MAX_MOTOR_PULSE) output = MAX_MOTOR_PULSE;
    if (output < -MAX_MOTOR_PULSE) output = -MAX_MOTOR_PULSE;

    return output;
}
