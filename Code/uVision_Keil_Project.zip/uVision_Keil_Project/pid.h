#ifndef PID_H
#define PID_H

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float prevError;
    float integral;
    float elapsedTime;   // Track elapsed time for initial slow start
} PID_t;

void PID_Init(PID_t *pid, float kp, float ki, float kd);
float PID_Compute(PID_t *pid, float setpoint, float measured, float dt);

#endif
