#include "TM4C123.h"
#include "pwm.h"
#include <stdint.h>

#define SYSCLK 16000000UL   // 16 MHz system clock

/*=========================================================
    GPIO PIN DEFINITIONS (ESC OUTPUTS)
=========================================================*/
/*
 * ESC1 -> PB6
 * ESC2 -> PB7
 */
#define PB6 (1U << 6)
#define PB7 (1U << 7)
#define GPIO_PORTB_EN (1U << 1)

/*=========================================================
    GLOBAL PWM VARIABLES (UPDATED BY PID IN main.c)
=========================================================*/
volatile unsigned long pulse_us1 = 1000;   // Motor 1 pulse (�s)
volatile unsigned long pulse_us2 = 1000;   // Motor 2 pulse (�s)

/*=========================================================
    TIMER INITIALIZATION
=========================================================*/

/**
 * @brief Timer0A @ 50 Hz (20 ms ESC frame)
 */
void Timer0A_50Hz_Init(void)
{
    SYSCTL->RCGCTIMER |= (1U << 0);
    for (volatile int i = 0; i < 3; i++);

    TIMER0->CTL = 0;
    TIMER0->CFG = 0x00;                 // 32-bit
    TIMER0->TAMR = 0x02;                // Periodic
    TIMER0->TAILR = (SYSCLK / 50) - 1;  // 20 ms
    TIMER0->ICR = 0x01;
    TIMER0->IMR = 0x01;

    NVIC_SetPriority(TIMER0A_IRQn, 1);
    NVIC_EnableIRQ(TIMER0A_IRQn);

    TIMER0->CTL |= 0x01;
}

/**
 * @brief One-shot timer for ESC1 (PB6)
 */
void Timer1A_OneShot_Init(void)
{
    SYSCTL->RCGCTIMER |= (1U << 1);
    for (volatile int i = 0; i < 3; i++);

    TIMER1->CTL = 0;
    TIMER1->CFG = 0x04;     // 16-bit
    TIMER1->TAMR = 0x01;   // One-shot
    TIMER1->ICR = 0x01;
    TIMER1->IMR = 0x01;

    NVIC_SetPriority(TIMER1A_IRQn, 2);
    NVIC_EnableIRQ(TIMER1A_IRQn);
}

/**
 * @brief One-shot timer for ESC2 (PB7)
 */
void Timer2A_OneShot_Init(void)
{
    SYSCTL->RCGCTIMER |= (1U << 2);
    for (volatile int i = 0; i < 3; i++);

    TIMER2->CTL = 0;
    TIMER2->CFG = 0x04;     // 16-bit
    TIMER2->TAMR = 0x01;   // One-shot
    TIMER2->ICR = 0x01;
    TIMER2->IMR = 0x01;

    NVIC_SetPriority(TIMER2A_IRQn, 2);
    NVIC_EnableIRQ(TIMER2A_IRQn);
}

/*=========================================================
    TIMER INTERRUPT HANDLERS
=========================================================*/

/**
 * @brief 50 Hz base interrupt
 *        Generates ESC PWM pulses
 *        (NO CONTROL LOGIC HERE)
 */
void TIMER0A_Handler(void)
{
    TIMER0->ICR = 0x01;

    /* Start both PWM pulses */
    GPIOB->DATA |= (PB6 | PB7);

    TIMER1->TAILR = (SYSCLK / 1000000UL) * pulse_us1 - 1;
    TIMER2->TAILR = (SYSCLK / 1000000UL) * pulse_us2 - 1;

    TIMER1->CTL |= 0x01;
    TIMER2->CTL |= 0x01;
}

/**
 * @brief Ends ESC1 pulse (PB6 LOW)
 */
void TIMER1A_Handler(void)
{
    TIMER1->ICR = 0x01;
    GPIOB->DATA &= ~PB6;
}

/**
 * @brief Ends ESC2 pulse (PB7 LOW)
 */
void TIMER2A_Handler(void)
{
    TIMER2->ICR = 0x01;
    GPIOB->DATA &= ~PB7;
}

/*=========================================================
    GPIO INIT (ESC OUTPUT PINS)
=========================================================*/

/**
 * @brief Initialize PB6 & PB7 as ESC outputs
 */
