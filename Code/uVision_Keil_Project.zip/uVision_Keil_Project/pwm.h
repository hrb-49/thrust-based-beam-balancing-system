#ifndef PWM_H
#define PWM_H

#include "TM4C123.h"

/*=========================================================
    GPIO CONFIGURATION
=========================================================*/



/*=========================================================
    PWM TIMER CONFIGURATION
=========================================================*/

/**
 * @brief Configures Timer0A to generate a 50 Hz base period
 *        required for ESC control (20 ms frame).
 *
 * This timer triggers the generation of PWM pulses
 * for both ESCs.
 */
void Timer0A_50Hz_Init(void);

/**
 * @brief Configures Timer1A in one-shot mode to generate
 *        PWM pulse for ESC1.
 *
 * **ESC1 Pin Mapping:**
 * - PB6 (Motor 1 ESC signal)
 */
void Timer1A_OneShot_Init(void);

/**
 * @brief Configures Timer2A in one-shot mode to generate
 *        PWM pulse for ESC2.
 *
 * **ESC2 Pin Mapping:**
 * - PB7 (Motor 2 ESC signal)
 */
void Timer2A_OneShot_Init(void);

/*=========================================================
    ADC CONFIGURATION (POTENTIOMETER)
=========================================================*/

/**
 * @brief Initializes ADC0 to read a single potentiometer.
 *
 * **Hardware Mapping:**
 * - Potentiometer ? PE4
 * - ADC Channel  : AIN9
 *
/*=========================================================
    PWM OUTPUT VARIABLES
=========================================================*/

/**
 * @brief PWM pulse widths for ESCs (in microseconds).
 *
 * Range typically:
 * - 1000 �s : Minimum throttle
 * - 1500 �s : Neutral
 * - 2000 �s : Maximum throttle
 */
extern volatile unsigned long pulse_us1;   // ESC1 (PB6)
extern volatile unsigned long pulse_us2;   // ESC2 (PB7)

#endif /* PWM_H */
