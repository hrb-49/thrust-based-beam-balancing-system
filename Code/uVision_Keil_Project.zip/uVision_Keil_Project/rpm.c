#include "rpm.h"
#include "TM4C123.h"

/*=========================================================
    RPM SENSOR PIN DEFINITIONS
=========================================================*/
#define PB2 (1U << 2)    // Hall Sensor Motor 1
#define PB3 (1U << 3)    // Hall Sensor Motor 2

/*=========================================================
    HALL SENSOR CONFIGURATION
=========================================================*/
/*
 * A2212 BLDC motor typically has 14 poles (7 pole pairs)
 * Hall sensor detects multiple magnetic transitions
 * This value MUST be calibrated experimentally
 */
#define PULSES_PER_REV 8U     // <<<<<< CRITICAL FIX

/*=========================================================
    GLOBAL VARIABLES
=========================================================*/
volatile unsigned int count_1 = 0;
volatile unsigned int count_2 = 0;

volatile unsigned int rpm1 = 0;
volatile unsigned int rpm2 = 0;

/*=========================================================
    RPM SENSOR 1 INIT (PB2)
=========================================================*/
void RPM_Sensor1_Input_Init_PB2(void)
{
    SYSCTL->RCGCGPIO |= (1U << 1);
    while (!(SYSCTL->PRGPIO & (1U << 1)));

    GPIOB->DIR &= ~PB2;
    GPIOB->DEN |= PB2;
    GPIOB->PUR |= PB2;                 // Pull-up for Hall sensor

    GPIOB->IS  &= ~PB2;                // Edge-sensitive
    GPIOB->IBE &= ~PB2;                // Single edge
    GPIOB->IEV |= PB2;                 // Rising edge
    GPIOB->ICR |= PB2;
    GPIOB->IM  |= PB2;

    NVIC_SetPriority(GPIOB_IRQn, 4);
    NVIC_EnableIRQ(GPIOB_IRQn);
}

/*=========================================================
    RPM SENSOR 2 INIT (PB3)
=========================================================*/
void RPM_Sensor2_Input_Init_PB3(void)
{
    SYSCTL->RCGCGPIO |= (1U << 1);
    while (!(SYSCTL->PRGPIO & (1U << 1)));

    GPIOB->DIR &= ~PB3;
    GPIOB->DEN |= PB3;
    GPIOB->PUR |= PB3;

    GPIOB->IS  &= ~PB3;
    GPIOB->IBE &= ~PB3;
    GPIOB->IEV |= PB3;
    GPIOB->ICR |= PB3;
    GPIOB->IM  |= PB3;
}

/*=========================================================
    TIMER3A INIT � 1 SECOND GATE TIME
=========================================================*/
void RPM_Timer3A_1s_Init(void)
{
    SYSCTL->RCGCTIMER |= (1U << 3);
    while (!(SYSCTL->PRTIMER & (1U << 3)));

    TIMER3->CTL  = 0;
    TIMER3->CFG  = 0x00;               // 32-bit
    TIMER3->TAMR = 0x02;               // Periodic
    TIMER3->TAILR = 16000000 - 1;       // 1 second @ 16 MHz
    TIMER3->ICR  = 0x01;
    TIMER3->IMR |= 0x01;

    NVIC_SetPriority(TIMER3A_IRQn, 3);
    NVIC_EnableIRQ(TIMER3A_IRQn);

    TIMER3->CTL |= 0x01;
}

/*=========================================================
    GPIO PORT B INTERRUPT HANDLER
=========================================================*/
void GPIOB_Handler(void)
{
    unsigned int status = GPIOB->MIS;

    if (status & PB2)
    {
        GPIOB->ICR = PB2;
        count_1++;
    }

    if (status & PB3)
    {
        GPIOB->ICR = PB3;
        count_2++;
    }
}

/*=========================================================
    TIMER3A INTERRUPT HANDLER � RPM CALCULATION
=========================================================*/
void TIMER3A_Handler(void)
{
    TIMER3->ICR = 0x01;

    /*
     * RPM = (pulses / pulses_per_rev) * 60
     * Gate time = 1 second
     */
    rpm1 = (count_1 * 60U) / PULSES_PER_REV;
    rpm2 = (count_2 * 60U) / PULSES_PER_REV;

    count_1 = 0;
    count_2 = 0;
}