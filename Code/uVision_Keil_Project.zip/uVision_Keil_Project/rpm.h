#ifndef RPM_H
#define RPM_H

#include "TM4C123.h"   // Device-specific register definitions for TM4C123 microcontroller

/*---------------------------------------------------------
    Function Prototypes
---------------------------------------------------------*/

/**
 * @brief Initializes **GPIO Port B, Pin 2 (PB2)** as input for **RPM Sensor 1**.
 * 
 * - PB2 is configured as a **digital input pin**.
 * - The pin is connected to **RPM Sensor 1 output**, generating pulses proportional to rotational speed.
 * - The interrupt is configured on the **rising edge** to count each rotation pulse.
 * 
 * @note This setup enables the microcontroller to measure RPM by counting rising edges on PB2.
 */
void RPM_Sensor1_Input_Init_PB2(void);

/**
 * @brief Initializes **GPIO Port B, Pin 3 (PB3)** as input for **RPM Sensor 2**.
 * 
 * - PB3 is configured as a **digital input pin**.
 * - The pin receives pulses from **RPM Sensor 2 output**, where each pulse corresponds to one rotation.
 * - The interrupt is configured on the **rising edge** for pulse counting.
 * 
 * @note This function allows the microcontroller to independently track the RPM of a second motor or wheel.
 */
void RPM_Sensor2_Input_Init_PB3(void);

/**
 * @brief Configures **Timer3A** to generate periodic interrupts every **1 second**.
 * 
 * - Timer3A is used as a **time base** to calculate RPM.
 * - On every interrupt (1-second interval), pulse counts from PB2 and PB3 are processed to compute RPM.
 * - The timer interrupt can also trigger display or UART updates for real-time RPM monitoring.
 * 
 * @note This function synchronizes RPM measurements by defining a consistent measurement window (1s).
 */
void RPM_Timer3A_1s_Init(void);


#endif /* RPM_H */
