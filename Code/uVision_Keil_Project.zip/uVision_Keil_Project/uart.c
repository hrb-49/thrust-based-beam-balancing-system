#include "TM4C123.h"
#include <stdint.h>

/*---------------------------------------------------------
    PLL Initialization
---------------------------------------------------------*/
void PLL_Init(void) {
    SYSCTL->RCC2 |= 0x80000000;           // USERCC2
    SYSCTL->RCC2 |= 0x00000800;           // BYPASS PLL
    SYSCTL->RCC  = (SYSCTL->RCC & ~0x7C0) + 0x540;
    SYSCTL->RCC2 &= ~0x70;                // Main oscillator
    SYSCTL->RCC2 &= ~0x2000;              // Power up PLL
    SYSCTL->RCC2 |= 0x40000000;           // 400 MHz PLL
    SYSCTL->RCC2 = (SYSCTL->RCC2 & ~0x1FC00000) + (24 << 22);
    while ((SYSCTL->RIS & 0x40) == 0);    // Wait for lock
    SYSCTL->RCC2 &= ~0x00000800;          // Enable PLL
}

/*---------------------------------------------------------
    UART0 Initialization
---------------------------------------------------------*/
void UART0_Init(void) {
    SYSCTL->RCGCUART |= 1;       
    SYSCTL->RCGCGPIO |= 1;       
    for (volatile int i = 0; i < 3; i++);

    GPIOA->AFSEL |= (1<<0) | (1<<1);
    GPIOA->DEN   |= (1<<0) | (1<<1);
    GPIOA->PCTL  &= ~0xFF;
    GPIOA->PCTL  |= 0x11;    
    GPIOA->AMSEL &= ~((1<<0) | (1<<1));

    UART0->CTL  &= ~1;           
    UART0->IBRD  = 104;          // 9600 @16MHz
    UART0->FBRD  = 11;
    UART0->LCRH  = 0x70;         // 8N1, FIFO
    UART0->CC    = 0;            // system clock
    UART0->CTL  |= 0x301;        // RXE, TXE, UARTEN
}

/*---------------------------------------------------------
    TX: send single char
---------------------------------------------------------*/
void UART0_TxChar(char c)
{
    while (UART0->FR & (1 << 5));  // Wait while TX FIFO full
    UART0->DR = c;
}

/*---------------------------------------------------------
    Print String
---------------------------------------------------------*/
void UART0_PrintString(const char *s) {
    while (*s) {
        UART0_TxChar(*s++);
    }
}

/*---------------------------------------------------------
    Print Unsigned Number
---------------------------------------------------------*/
void UART0_PrintNumber(uint32_t n) {
    char buf[12];
    int i = 0;

    if (n == 0) {
        UART0_TxChar('0');
        return;
    }

    while (n > 0 && i < 11) {
        buf[i++] = (n % 10) + '0';
        n /= 10;
    }

    while (i--) {
        UART0_TxChar(buf[i]);
    }
}

/*---------------------------------------------------------
    Print Signed Number (e.g. mA)
---------------------------------------------------------*/
void UART0_PrintSignedNumber(int32_t num)
{
    if (num < 0) {
        UART0_TxChar('-');
        num = -num;
    }
    UART0_PrintNumber((uint32_t)num);
}

/*---------------------------------------------------------
    Print current from milli-amps as "xx.xx A"
    Input: mA (e.g. 750 -> "0.75", 1200 -> "1.20")
---------------------------------------------------------*/
void UART0_PrintCurrentA_from_mA(int32_t mA)
{
    // 1 A = 1000 mA
    // 0.01 A step -> centiA = mA / 10
    int32_t centiA = mA / 10;        // signed

    if (centiA < 0) {
        UART0_TxChar('-');
        centiA = -centiA;
    }

    int32_t intPart  = centiA / 100;    // whole Amps
    int32_t fracPart = centiA % 100;    // 0..99

    UART0_PrintNumber((uint32_t)intPart);
    UART0_TxChar('.');
    if (fracPart < 10) {
        UART0_TxChar('0');
    }
    UART0_PrintNumber((uint32_t)fracPart);
}
// ================== MISSING FUNCTIONS ==================
void UART0_PrintHex(uint8_t val)
{
    const char *hex = "0123456789ABCDEF";
    UART0_TxChar(hex[(val >> 4) & 0x0F]);
    UART0_TxChar(hex[val & 0x0F]);
}

void UART0_PrintFloat(float num, uint8_t decimals)
{
    if (num < 0) {
        UART0_TxChar('-');
        num = -num;
    }

    // Integer part
    uint32_t int_part = (uint32_t)num;
    UART0_PrintNumber(int_part);
    UART0_TxChar('.');

    // Fractional part
    float frac = num - int_part;
    for (uint8_t i = 0; i < decimals; i++) {
        frac *= 10;
        uint8_t digit = (uint8_t)frac;
        UART0_TxChar('0' + digit);
        frac -= digit;
    }
}
