#ifndef UART_H
#define UART_H

#include "TM4C123.h"
#include <stdint.h>

void PLL_Init(void);
void UART0_Init(void);

void UART0_TxChar(char c);
void UART0_PrintString(const char *s);
void UART0_PrintNumber(uint32_t n);
void UART0_PrintSignedNumber(int32_t num);

// naya helper: mA ? "xx.xx A"
void UART0_PrintCurrentA_from_mA(int32_t mA);
// uart.h ke end mein yeh do lines daal do

void UART0_PrintHex(uint8_t val);

void UART0_PrintFloat(float num, uint8_t decimals);
#endif
